package com.example.kotlintodo.utils

data class ToDoData(val taskId: String, var task : String)
